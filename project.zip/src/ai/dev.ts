import { config } from 'dotenv';
config();

import '@/ai/flows/smart-message-trigger.ts';